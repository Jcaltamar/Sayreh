<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	// add purchase code on settings
    $data = array(
    	'type' 		  => 'purchase_code',
    	'description' => ''
    );
    $CI->db->insert('settings', $data);


	// create complaints table
	$complaints_fields = array(
		'complaints_id' => array(
			'type' => 'INT',
			'auto_increment' => TRUE,
		),
		'user_id' => array(
			'type' => 'TEXT',
			'null' => TRUE,
		),
		'title' => array(
			'type' => 'VARCHAR',
			'constraint' => '255',
			'null' => TRUE,
		),
		'summary' => array(
			'type' => 'TEXT',
			'null' => TRUE,
		),
		'timestamp' => array(
			'type' => 'INT',
			'null' => TRUE,
		),
	);
	$CI->dbforge->add_key('complaints_id', TRUE);
	$CI->dbforge->add_field($complaints_fields);
	$CI->dbforge->create_table('complaints');

	// create job_history table
	$job_history_fields = array(
		'job_history_id' => array(
			'type' => 'INT',
			'auto_increment' => TRUE,
		),
		'user_id' => array(
			'type' => 'TEXT',
			'null' => TRUE,
		),
		'company_name' => array(
			'type' => 'VARCHAR',
			'constraint' => '255',
			'null' => TRUE,
		),
		'department' => array(
			'type' => 'VARCHAR',
			'constraint' => '255',
			'null' => TRUE,
		),
		'designation' => array(
			'type' => 'VARCHAR',
			'constraint' => '255',
			'null' => TRUE,
		),
		'timestamp_from' => array(
			'type' => 'INT',
			'null' => TRUE,
		),
		'timestamp_to' => array(
			'type' => 'INT',
			'null' => TRUE,
		),
	);
	$CI->dbforge->add_key('job_history_id', TRUE);
	$CI->dbforge->add_field($job_history_fields);
	$CI->dbforge->create_table('job_history');
?>
